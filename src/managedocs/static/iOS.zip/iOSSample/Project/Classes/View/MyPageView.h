//
//  GodMyPageView.h
//  Project
//
//  Created by inukai1 on 2015/05/30.
//  Copyright (c) 2015年 shuhei_ohono. All rights reserved.
//

#import "common.h"

@interface MyPageView : UIView

- (id)initWithFrame:(CGRect)argFrame WithDelegate:(id)delegate;


@end
