//
//  UIImage+custom.h
//
//  Created by saimushi on 2013/10/13.
//

#import <Foundation/Foundation.h>

@interface UIImage (custom)

+ (UIImage *)imageWithColor:(UIColor *)color;

@end
