//
//  UIBarButtonItem+initwithimage.h
//
//  Created by saimushi on 2014/06/09.
//  Copyright (c) 2014年 shuhei_ohono. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIBarButtonItem (initwithimage)

- (UIBarButtonItem *)initWithImage:(UIImage *)image target:(id)target action:(SEL)action;

@end
