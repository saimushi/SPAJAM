@interface NSString (UTF8URLEncodingConvert)
+ (NSString*)UTF8URLEncoding:(NSString *)argStr;
@end