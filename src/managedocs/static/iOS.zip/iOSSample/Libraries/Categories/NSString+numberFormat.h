@interface NSString (numberFormat)
- (NSString *)getMoneyFormatString;
@end
