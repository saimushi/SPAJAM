//
//  ProjectModelBase.h
//
//  Created by saimushi on 2015/05/25.
//  Copyright (c) 2014年 saimushi. All rights reserved.
//

#import "ModelBase.h"
#import "common.h"

@interface ProjectModelBase : ModelBase

/* Project専用のModelBase処理を追加する場合はこのファイルに */

@end
